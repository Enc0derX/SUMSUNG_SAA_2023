package com.doodlejump;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;

public class PreferenceManager {
    private static PreferenceManager instance;

    public static void initialize() {
        if(instance == null) {
            instance = new PreferenceManager();
        }
    }

    private Preferences preferences;

    private PreferenceManager() {
        preferences = Gdx.app.getPreferences("com.doodlejump");
    }

    public static void setScore(int score) {
        instance.preferences.putInteger("score", score);
        instance.preferences.flush();
    }

    public static int getScore() {
        return instance.preferences.getInteger("score");
    }
}
