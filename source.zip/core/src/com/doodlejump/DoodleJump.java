package com.doodlejump;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.ScreenUtils;
import com.doodlejump.screen.GameOverScreen;
import com.doodlejump.screen.GameScreen;
import com.doodlejump.screen.MenuScreen;

public class DoodleJump extends Game {
    private SpriteBatch batch;

    private Skin skin;
    Color clearColor;

    private MenuScreen menuScreen;
    private GameScreen gameScreen;
    private GameOverScreen gameOverScreen;

    @Override
    public void create () {
        AudioManager.initialize();
        PreferenceManager.initialize();

        batch = new SpriteBatch();

        skin = new Skin(Gdx.files.internal("img/skin.json"));
        clearColor = skin.getColor("clear");

        menuScreen = new MenuScreen(this);
        gameScreen = new GameScreen(this);
        gameOverScreen = new GameOverScreen(this);

        setScreen(menuScreen);
    }

    public void startGame() {
        setScreen(gameScreen);
    }

    public void gameOver(int score) {
        if(score > PreferenceManager.getScore()) {
            PreferenceManager.setScore(score);
        }
        gameOverScreen.setScore(score);
        setScreen(gameOverScreen);
    }

    public void menu() {
        setScreen(menuScreen);
    }

    @Override
    public void render () {
        ScreenUtils.clear(clearColor);
        super.render();
    }
    
    @Override
    public void dispose () {
        super.dispose();

        menuScreen.dispose();
        gameScreen.dispose();
        gameOverScreen.dispose();

        skin.dispose();

        batch.dispose();

        AudioManager.dispose();
    }

    public SpriteBatch getBatch() {
        return batch;
    }

    public Skin getSkin() {
        return skin;
    }
}
