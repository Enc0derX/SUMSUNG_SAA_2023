package com.doodlejump;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;

public class AudioManager {
    private static AudioManager instance;

    private Sound jumpSound;

    private AudioManager() {
        jumpSound = Gdx.audio.newSound(Gdx.files.internal("snd/jump.wav"));
    }

    public static void initialize() {
        if(instance == null) {
            instance = new AudioManager();
        }
    }

    public static void playJumpSound() {
        instance.jumpSound.play();
    }

    public static void dispose() {
        if(instance != null) {
            instance.jumpSound.dispose();
        }
    }
}
