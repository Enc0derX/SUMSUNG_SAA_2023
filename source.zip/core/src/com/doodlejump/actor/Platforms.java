package com.doodlejump.actor;

import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.doodlejump.actor.Platform.PlatformType;

public class Platforms extends Group {
    private static final float NORMAL_HEIGHT = 5000f;
    private static final float BREAKING_HEIGHT = 15000f;

    private Group bulletGroup;
    private Player player;
    private Skin skin;

    private float height = -960f;
    private float step = 1f;

    public Platforms(Group bulletGroup, Player player, Skin skin) {
        this.bulletGroup = bulletGroup;
        this.player = player;
        this.skin = skin;
    }

    @Override
    public void act(float delta) {
        while(height
            < getStage().getCamera().position.y + getStage().getHeight() / 2f
        ) {
            PlatformType type;
            if(height < NORMAL_HEIGHT) {
                type = PlatformType.NORMAL;
            } else if(height < BREAKING_HEIGHT) {
                type =
                    MathUtils.randomBoolean(
                        (height - NORMAL_HEIGHT)
                            / (BREAKING_HEIGHT - NORMAL_HEIGHT)
                            / 2f
                    )
                    ? PlatformType.BREAKING
                    : PlatformType.NORMAL;
            } else {
                type = MathUtils.randomBoolean()
                    ? PlatformType.NORMAL
                    : PlatformType.BREAKING;
            }
            Platform platform = new Platform(height, type, player, skin);
            addActor(platform);

            if(step > 200f && MathUtils.randomBoolean(0.05f)) {
                addActor(new Upgrade(platform, player, skin));
            } else if(step > 250f && MathUtils.randomBoolean(0.05f)) {
                addActor(new Enemy(platform, bulletGroup, player, skin));
            }

            height += step;
            step += 1f;
        }

        super.act(delta);
    }
}
