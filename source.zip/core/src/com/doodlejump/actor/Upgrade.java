package com.doodlejump.actor;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.Align;

public class Upgrade extends Actor {
    private static enum UpgradeType {
        SHIELD,
        BOOST,
    }

    private UpgradeType type =
        UpgradeType.values()[MathUtils.random(UpgradeType.values().length - 1)];
    private Player player;
    private TextureRegion region;

    private Color tmp = new Color();
    private boolean fading = false;

    public Upgrade(Platform platform, Player player, Skin skin) {
        this.player = player;

        switch(type) {
            case SHIELD:
                region = skin.getRegion("upgrade/shield");
                break;
            case BOOST:
                region = skin.getRegion("upgrade/boost");
                break;
        }

        setSize(96f, 96f);
        addAction(Actions.run(() -> {
            setPosition(
                platform.getX(Align.center),
                platform.getTop() + 32f,
                Align.bottom | Align.center
            );
        }));
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        tmp.set(batch.getColor());
        batch.setColor(getColor());
        batch.draw(region, getX(), getY(), getWidth(), getHeight());
        batch.setColor(tmp);
    }

    @Override
    public void act(float delta) {
        super.act(delta);

        if(getStage() == null) {
            return;
        }

        if(getTop()
            < getStage().getCamera().position.y - getStage().getHeight() / 2f
        ) {
            clear();
            remove();
            return;
        }

        if(!fading
            && !player.isDead()
            && player.getRight() > getX()
            && player.getX() < getRight()
            && player.getTop() > getY()
            && player.getY() < getTop()
        ) {
            switch(type) {
                case SHIELD:
                    player.addShield();
                    break;
                case BOOST:
                    player.addBoost();
                    break;
            }

            addAction(Actions.sequence(
                Actions.alpha(0f, 0.5f, Interpolation.fade),
                Actions.removeActor()
            ));
            fading = true;
        }
    }
}
