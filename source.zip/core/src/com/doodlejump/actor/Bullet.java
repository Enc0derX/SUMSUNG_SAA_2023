package com.doodlejump.actor;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.Align;

public class Bullet extends Actor {
    private TextureRegion region;

    public Bullet(Player player, Skin skin) {
        region = skin.getRegion("bullet");

        setSize(96f, 96f);
        setPosition(
            player.getX(Align.center),
            player.getY(Align.center),
            Align.center
        );
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        batch.draw(region, getX(), getY(), getWidth(), getHeight());
    }

    @Override
    public void act(float delta) {
        moveBy(0f, 3072f * delta);

        if(getY()
            > getStage().getCamera().position.y + getStage().getHeight() / 2f
        ) {
            remove();
        }
    }
}
