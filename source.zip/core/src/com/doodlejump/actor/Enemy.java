package com.doodlejump.actor;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.Align;

public class Enemy extends Actor {
    private static final float PADDING = 36f;

    private Group bulletGroup;
    private Player player;
    private TextureRegion region;

    private Color tmp = new Color();
    private boolean fading = false;

    public Enemy(
        Platform platform,
        Group bulletGroup,
        Player player,
        Skin skin
    ) {
        this.bulletGroup = bulletGroup;
        this.player = player;
        region = skin.getRegion("enemy");

        setSize(192f, 192f);
        addAction(Actions.run(() -> {
            setPosition(
                platform.getX(Align.center),
                platform.getTop(),
                Align.bottom | Align.center
            );
        }));
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        tmp.set(batch.getColor());
        batch.setColor(getColor());
        batch.draw(region, getX(), getY(), getWidth(), getHeight());
        batch.setColor(tmp);
    }

    @Override
    public void act(float delta) {
        super.act(delta);

        if(getStage() == null) {
            return;
        }

        if(getTop()
            < getStage().getCamera().position.y - getStage().getHeight() / 2f
        ) {
            clear();
            remove();
            return;
        }

        for(Actor bullet: bulletGroup.getChildren()) {
            if(!fading
                && bullet.getRight() > getX()
                && bullet.getX() < getRight()
                && bullet.getTop() > getY()
                && bullet.getY() < getTop()
            ) {
                bullet.remove();
                addAction(Actions.sequence(
                    Actions.alpha(0f, 0.5f, Interpolation.fade),
                    Actions.removeActor()
                ));
                fading = true;
            }
        }

        if(!fading
            && !player.isDead()
            && player.getRight() > getX() + PADDING
            && player.getX() < getRight() - PADDING
            && player.getTop() > getY() + PADDING
            && player.getY() < getTop() - PADDING
        ) {
            player.die();
        }
    }
}
