package com.doodlejump.actor;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.utils.Align;
import com.doodlejump.AudioManager;
import com.doodlejump.DoodleJump;

public class Player extends Actor {
    private Group bulletGroup;
    private DoodleJump game;
    private TextureRegion upRegion;
    private TextureRegion downRegion;
    private TextureRegion shootRegion;
    private TextureRegion shieldRegion;
    private TextureRegion region;

    private Vector3 tmp = new Vector3();
    private Vector2 velocity = new Vector2();

    private float shield = 0f;
    private int boost = 0;
    private float shoot = 0f;
    private boolean flip = false;
    private boolean dead = false;

    public Player(Group bulletGroup, DoodleJump game) {
        this.bulletGroup = bulletGroup;
        this.game = game;
        upRegion = new TextureRegion(game.getSkin().getRegion("player/up"));
        downRegion = new TextureRegion(game.getSkin().getRegion("player/down"));
        shootRegion =
            new TextureRegion(game.getSkin().getRegion("player/shoot"));
        shieldRegion =
            new TextureRegion(game.getSkin().getRegion("player/shield"));

        setSize(192f, 192f);
        setPosition(0f, 0f, Align.center);
    }

    public boolean isFalling() {
        return velocity.y < 0f;
    }

    public void jump() {
        if(boost > 0) {
            velocity.y = 3072f;
            boost--;
        } else {
            velocity.y = 2048f;
        }

        AudioManager.playJumpSound();
    }

    public void addShield() {
        shield += 5f;
    }

    public void addBoost() {
        boost++;
    }

    public void shoot() {
        if(!dead && bulletGroup.getChildren().size < 3) {
            bulletGroup.addActor(new Bullet(this, game.getSkin()));
            shoot = 0.5f;
        }
    }

    public void die() {
        if(shield == 0f) {
            velocity.y = 1024f;
            dead = true;
        }
    }

    public boolean isDead() {
        return dead;
    }

    public int getScore() {
        return (int)(getStage().getCamera().position.y / 192f);
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        if(shoot > 0f) {
            region = shootRegion;
        } else {
            region = velocity.y > 0f ? upRegion : downRegion;
        }
        if(velocity.x < 0f) {
            flip = true;
        }
        if(velocity.x > 0f) {
            flip = false;
        }
        if(flip) {
            region.flip(!region.isFlipX(), false);
        } else {
            region.flip(region.isFlipX(), false);
        }

        batch.draw(region, getX(), getY(), getWidth(), getHeight());

        if(shield > 0f) {
            batch.draw(shieldRegion, getX(), getY(), getWidth(), getHeight());
        }

        toBack();
    }

    @Override
    public void act(float delta) {
        float direction = 0f;
        if(Gdx.input.isKeyPressed(Keys.LEFT)) {
            direction -= 0.5f;
        }
        if(Gdx.input.isKeyPressed(Keys.RIGHT)) {
            direction += 0.5f;
        }
        if(direction == 0f) {
            tmp.set(
                Gdx.input.getAccelerometerX(),
                Gdx.input.getAccelerometerY(),
                Gdx.input.getAccelerometerZ()
            );
            if(!tmp.isZero()) {
                direction = -tmp.x / tmp.len();
            }
        }

        velocity.x = dead ? 0f : 2160f * direction;
        velocity.y -= 2048f * delta;
        moveBy(velocity.x * delta, velocity.y * delta);

        if(getRight() < -getStage().getWidth() / 2f) {
            moveBy(getStage().getWidth() + getWidth(), 0f);
        }
        if(getX() > getStage().getWidth() / 2f) {
            moveBy(-getStage().getWidth() - getWidth(), 0f);
        }

        if(!dead && getStage().getCamera().position.y < getY(Align.center)) {
            getStage().getCamera().position.y = getY(Align.center);
        }

        if(getTop()
            < getStage().getCamera().position.y - getStage().getHeight() / 2f
        ) {
            if(shield > 0f) {
                velocity.y = 2048f;
            } else {
                game.gameOver(getScore());
            }
        }

        shield -= delta;
        if(shield < 0f) {
            shield = 0f;
        }

        shoot -= delta;
        if(shoot < 0f) {
            shoot = 0f;
        }

        toFront();
    }
}
