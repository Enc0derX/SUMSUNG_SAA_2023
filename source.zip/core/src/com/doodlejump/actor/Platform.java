package com.doodlejump.actor;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

public class Platform extends Actor {
    private static final float FADE_DURATION = 0.5f;

    public static enum PlatformType {
        NORMAL,
        BREAKING,
    }

    private PlatformType type;
    private Player player;
    private TextureRegion region;

    private Color tmp = new Color();

    private boolean breaking = false;

    public Platform(float y, PlatformType type, Player player, Skin skin) {
        this.type = type;
        this.player = player;

        switch(type) {
            case NORMAL:
                region = skin.getRegion("platform/normal");
                break;
            case BREAKING:
                region = skin.getRegion("platform/breaking");
                break;
        }

        setSize(192f, 48f);
        addAction(Actions.run(() -> {
            setPosition(
                MathUtils.random(
                    -getStage().getWidth() / 2f,
                    getStage().getWidth() / 2f - getWidth()
                ),
                y
            );
        }));
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        tmp.set(batch.getColor());
        batch.setColor(getColor());
        batch.draw(region, getX(), getY(), getWidth(), getHeight());
        batch.setColor(tmp);
    }

    @Override
    public void act(float delta) {
        super.act(delta);

        if(getStage() == null) {
            return;
        }

        if(getTop()
            < getStage().getCamera().position.y - getStage().getHeight() / 2f
        ) {
            clear();
            remove();
            return;
        }

        if(!breaking
            && !player.isDead()
            && player.isFalling()
            && player.getRight() > getX()
            && player.getX() < getRight()
            && player.getY() > getY()
            && player.getY() < getTop()
        ) {
            player.jump();

            if(type == PlatformType.BREAKING) {
                addAction(Actions.sequence(
                    Actions.parallel(
                        Actions.alpha(0f, FADE_DURATION, Interpolation.fade),
                        Actions.moveBy(
                            0f,
                            -48f,
                            FADE_DURATION,
                            Interpolation.fade
                        )
                    ),
                    Actions.removeActor()
                ));
                breaking = true;
            }
        }
    }
}
