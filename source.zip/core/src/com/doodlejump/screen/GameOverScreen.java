package com.doodlejump.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.doodlejump.Constants;
import com.doodlejump.DoodleJump;
import com.doodlejump.PreferenceManager;

public class GameOverScreen extends ScreenAdapter {
    private Stage stage;

    private Label highScoreLabel;
    private Label scoreLabel;

    public GameOverScreen(DoodleJump game) {
        stage = new Stage(
            new ExtendViewport(Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT),
            game.getBatch()
        );

        Table rootTable = new Table();
        rootTable.setFillParent(true);

        rootTable.add().expandY();
        rootTable.row();

        Label titleLabel =
            new Label("GAME OVER", game.getSkin(), "press-start-2p-large");
        rootTable.add(titleLabel).pad(64f);

        rootTable.row();

        highScoreLabel =
            new Label("", game.getSkin(), "press-start-2p-small");
        rootTable.add(highScoreLabel);

        rootTable.row();

        scoreLabel =
            new Label("", game.getSkin(), "press-start-2p-small");
        rootTable.add(scoreLabel).pad(32f);

        rootTable.row();
        rootTable.add().expandY();
        rootTable.row();

        TextButton restartButton =
            new TextButton("RESTART", game.getSkin(), "menu");
        restartButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.startGame();
            }
        });
        rootTable.add(restartButton).size(768f, 192f).pad(32f);

        rootTable.row();

        TextButton menuButton =
            new TextButton("MENU", game.getSkin(), "menu");
        menuButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.menu();
            }
        });
        rootTable.add(menuButton).size(768f, 192f).pad(32f);

        rootTable.row();
        rootTable.add().expandY();

        stage.addActor(rootTable);
    }

    public void setScore(int score) {
        scoreLabel.setText("SCORE: " + score);
    }

    @Override
    public void show() {
        highScoreLabel.setText("HIGH SCORE: " + PreferenceManager.getScore());

        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);
    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
