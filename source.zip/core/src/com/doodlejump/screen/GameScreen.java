package com.doodlejump.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Container;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Widget;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.doodlejump.Constants;
import com.doodlejump.DoodleJump;
import com.doodlejump.actor.Platforms;
import com.doodlejump.actor.Player;

public class GameScreen extends ScreenAdapter {
    private DoodleJump game;

    private Stage stage;
    private Stage uiStage;

    private Player player;
    private Platforms platforms;

    public GameScreen(DoodleJump game) {
        this.game = game;
        stage = new Stage(
            new ExtendViewport(Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT),
            game.getBatch()
        );
        uiStage = new Stage(
            new ExtendViewport(Constants.SCREEN_WIDTH, Constants.SCREEN_HEIGHT),
            game.getBatch()
        );

        Widget button = new Widget();
        button.setFillParent(true);
        button.addListener(new InputListener() {
            @Override
            public boolean touchDown(
                InputEvent event,
                float x,
                float y,
                int pointer,
                int button
            ) {
                player.shoot();
                return true;
            }
        });
        uiStage.addActor(button);

        Label scoreLabel =
            new Label("", game.getSkin(), "press-start-2p-medium");
        scoreLabel.setTouchable(Touchable.disabled);
        scoreLabel.addAction(Actions.forever(Actions.run(() -> {
            scoreLabel.setText(player.getScore());
        })));
        Container<Label> scoreContainer = new Container<>(scoreLabel);
        scoreContainer.setFillParent(true);
        scoreContainer.top().left().pad(32f);
        uiStage.addActor(scoreContainer);
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(uiStage);

        stage.getCamera().position.setZero();

        stage.getRoot().clearChildren();

        Group bulletGroup = new Group();
        player = new Player(bulletGroup, game);
        stage.addActor(player);
        platforms =
            new Platforms(bulletGroup, player, game.getSkin());
        stage.addActor(platforms);
        stage.addActor(bulletGroup);
    }

    @Override
    public void render(float delta) {
        stage.act(delta);
        uiStage.act(delta);
        stage.draw();
        uiStage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height);
        uiStage.getViewport().update(width, height, true);
    }

    @Override
    public void hide() {
        Gdx.input.setInputProcessor(null);

        for(Actor actor: platforms.getChildren()) {
            actor.clear();
        }
    }

    @Override
    public void dispose() {
        stage.dispose();
        uiStage.dispose();
    }
}
