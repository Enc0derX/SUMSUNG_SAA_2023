package com.doodlejump;

public interface Constants {
    static final float SCREEN_WIDTH = 1080f;
    static final float SCREEN_HEIGHT = 1920f;
}
